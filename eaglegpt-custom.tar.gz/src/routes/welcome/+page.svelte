<script lang="ts">
	import { onMount, getContext } from 'svelte';
	import { goto } from '$app/navigation';
	import { fade } from 'svelte/transition';
	import { user, config, WEBUI_NAME } from '$lib/stores';
	import { WEBUI_BASE_URL } from '$lib/constants';
	import PreviewChat from '$lib/components/PreviewChat.svelte';

	const i18n = getContext('i18n');

	let showPreview = false;

	onMount(() => {
		// If user is already authenticated, redirect to main app
		if ($user) {
			goto('/');
		} else {
			// Show the preview after a short delay for smooth transition
			setTimeout(() => {
				showPreview = true;
			}, 100);
		}
	});

	// Reactive statement to handle user state changes
	$: if ($user) {
		goto('/');
	}

	const handleGetStarted = () => {
		goto('/auth');
	};

	const handleLogin = () => {
		goto('/auth');
	};
</script>

<svelte:head>
	<title>eagleGPT - AI Chat Assistant</title>
	<meta name="description" content="Experience the power of AI with eagleGPT - your intelligent chat assistant powered by advanced language models." />
</svelte:head>

{#if showPreview}
	<div class="min-h-screen bg-white dark:bg-gray-900" in:fade={{ duration: 300 }}>
		<!-- Hero Section -->
		<div class="relative overflow-hidden">
			<!-- Background with patriotic image -->
			<div
				class="absolute inset-0 bg-cover bg-center bg-no-repeat opacity-20"
				style="background-image: url('/static/flag-background-2.png')"
			></div>
			
			<!-- Header -->
			<header class="relative z-10 px-6 py-4">
				<div class="flex items-center justify-between max-w-7xl mx-auto">
					<div class="flex items-center space-x-3">
						<img
							src="{WEBUI_BASE_URL}/static/favicon.png"
							alt="eagleGPT"
							class="w-8 h-8"
						/>
						<h1 class="text-2xl font-bold text-gray-900 dark:text-white">
							{$WEBUI_NAME || 'eagleGPT'}
						</h1>
					</div>
					
					<div class="flex items-center space-x-4">
						<button
							on:click={handleLogin}
							class="px-4 py-2 text-sm font-medium text-gray-700 dark:text-gray-200 hover:text-gray-900 dark:hover:text-white transition-colors"
						>
							Sign In
						</button>
						<button
							on:click={handleGetStarted}
							class="px-6 py-2 bg-blue-600 hover:bg-blue-700 text-white font-medium rounded-lg transition-colors"
						>
							Get Started
						</button>
					</div>
				</div>
			</header>

			<!-- Hero Content -->
			<div class="relative z-10 px-6 py-12">
				<div class="max-w-4xl mx-auto text-center">
					<h2 class="text-4xl md:text-6xl font-bold text-gray-900 dark:text-white mb-6">
						Meet Your AI Assistant
					</h2>
					<p class="text-xl md:text-2xl text-gray-600 dark:text-gray-300 mb-8">
						Experience the power of advanced AI with eagleGPT. Chat, create, and collaborate with intelligence that understands you.
					</p>
					
					<!-- Feature badges -->
					<div class="flex flex-wrap justify-center gap-3 mb-8">
						<span class="px-4 py-2 bg-blue-100 dark:bg-blue-900 text-blue-800 dark:text-blue-200 rounded-full text-sm font-medium">
							🚀 Advanced AI Models
						</span>
						<span class="px-4 py-2 bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200 rounded-full text-sm font-medium">
							🔒 Secure & Private
						</span>
						<span class="px-4 py-2 bg-purple-100 dark:bg-purple-900 text-purple-800 dark:text-purple-200 rounded-full text-sm font-medium">
							⚡ Lightning Fast
						</span>
						<span class="px-4 py-2 bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200 rounded-full text-sm font-medium">
							🇺🇸 Made in America
						</span>
					</div>
				</div>
			</div>
		</div>

		<!-- Preview Chat Section -->
		<div class="relative z-10 px-6 pb-12">
			<div class="max-w-6xl mx-auto">
				<div class="bg-white dark:bg-gray-800 rounded-2xl shadow-xl border dark:border-gray-700 overflow-hidden">
					<!-- Chat preview header -->
					<div class="px-6 py-4 border-b dark:border-gray-700 bg-gray-50 dark:bg-gray-900">
						<div class="flex items-center justify-between">
							<h3 class="text-lg font-semibold text-gray-900 dark:text-white">
								Try eagleGPT - Interactive Preview
							</h3>
							<div class="flex items-center space-x-2">
								<div class="w-2 h-2 bg-red-400 rounded-full"></div>
								<div class="w-2 h-2 bg-yellow-400 rounded-full"></div>
								<div class="w-2 h-2 bg-green-400 rounded-full"></div>
							</div>
						</div>
					</div>
					
					<!-- Preview Chat Component -->
					<div class="h-96 md:h-[500px]">
						<PreviewChat {handleGetStarted} />
					</div>
				</div>
			</div>
		</div>

		<!-- Features Section -->
		<div class="bg-gray-50 dark:bg-gray-800 py-16">
			<div class="max-w-7xl mx-auto px-6">
				<div class="text-center mb-12">
					<h3 class="text-3xl font-bold text-gray-900 dark:text-white mb-4">
						Why Choose eagleGPT?
					</h3>
					<p class="text-lg text-gray-600 dark:text-gray-300">
						Built for Americans, by Americans. Experience AI without compromise.
					</p>
				</div>
				
				<div class="grid md:grid-cols-3 gap-8">
					<div class="text-center">
						<div class="w-16 h-16 bg-blue-100 dark:bg-blue-900 rounded-full flex items-center justify-center mx-auto mb-4">
							<span class="text-2xl">🛡️</span>
						</div>
						<h4 class="text-xl font-semibold text-gray-900 dark:text-white mb-2">
							Privacy First
						</h4>
						<p class="text-gray-600 dark:text-gray-300">
							Your conversations stay secure. Built with privacy and data protection as core principles.
						</p>
					</div>
					
					<div class="text-center">
						<div class="w-16 h-16 bg-green-100 dark:bg-green-900 rounded-full flex items-center justify-center mx-auto mb-4">
							<span class="text-2xl">⚡</span>
						</div>
						<h4 class="text-xl font-semibold text-gray-900 dark:text-white mb-2">
							Lightning Fast
						</h4>
						<p class="text-gray-600 dark:text-gray-300">
							Get instant responses powered by state-of-the-art AI models optimized for speed and accuracy.
						</p>
					</div>
					
					<div class="text-center">
						<div class="w-16 h-16 bg-red-100 dark:bg-red-900 rounded-full flex items-center justify-center mx-auto mb-4">
							<span class="text-2xl">🇺🇸</span>
						</div>
						<h4 class="text-xl font-semibold text-gray-900 dark:text-white mb-2">
							American Values
						</h4>
						<p class="text-gray-600 dark:text-gray-300">
							Built with American principles of freedom, innovation, and excellence at its core.
						</p>
					</div>
				</div>
			</div>
		</div>

		<!-- CTA Section -->
		<div class="bg-gradient-to-r from-blue-600 to-purple-600 py-16">
			<div class="max-w-4xl mx-auto text-center px-6">
				<h3 class="text-3xl md:text-4xl font-bold text-white mb-4">
					Ready to Experience the Future?
				</h3>
				<p class="text-xl text-blue-100 mb-8">
					Join thousands of users who trust eagleGPT for their AI needs.
				</p>
				<div class="flex flex-col sm:flex-row gap-4 justify-center">
					<button
						on:click={handleGetStarted}
						class="px-8 py-4 bg-white text-blue-600 font-bold text-lg rounded-lg hover:bg-gray-100 transition-colors"
					>
						Get Started Free
					</button>
					<button
						on:click={handleLogin}
						class="px-8 py-4 border-2 border-white text-white font-bold text-lg rounded-lg hover:bg-white hover:text-blue-600 transition-colors"
					>
						Sign In
					</button>
				</div>
			</div>
		</div>

		<!-- Footer -->
		<footer class="bg-gray-900 text-white py-8">
			<div class="max-w-7xl mx-auto px-6">
				<div class="flex flex-col md:flex-row justify-between items-center">
					<div class="flex items-center space-x-3 mb-4 md:mb-0">
						<img
							src="{WEBUI_BASE_URL}/static/favicon.png"
							alt="eagleGPT"
							class="w-6 h-6"
						/>
						<span class="text-lg font-semibold">{$WEBUI_NAME || 'eagleGPT'}</span>
					</div>
					<div class="text-sm text-gray-400">
						Powered by <a href="https://openwebui.com" target="_blank" class="hover:text-white transition-colors">Open WebUI</a>
						• Made with 🇺🇸 in America
					</div>
				</div>
			</div>
		</footer>
	</div>
{/if}